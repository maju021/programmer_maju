let clickcall = document.getElementById('clickcall');
let call = document.getElementById('call');
let callh = document.getElementById('callh');
clickcall.addEventListener('click', () => {
    call.style.display = 'block';
    callh.style.display = 'block';
    clickcall.style.display = 'none';
});
